<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* pages/index.twig */
class __TwigTemplate_41fa488d819d8a6ebd7980c015a388ef9f8e878fd4c3177a226a70a8ef44f939 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'head' => [$this, 'block_head'],
            'panel' => [$this, 'block_panel'],
            'content' => [$this, 'block_content'],
            'javascript' => [$this, 'block_javascript'],
            'style' => [$this, 'block_style'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "page.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("page.twig", "pages/index.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    Price Manager
";
    }

    // line 7
    public function block_head($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 8
        echo "    <script type=\"text/javascript\" src=\"content/js/productPage.js\"></script>
    <script type=\"text/javascript\" src=\"content/js/productFrom.js\"></script>
    <script type=\"text/javascript\" src=\"content/js/settingsPage.js\"></script>
";
    }

    // line 13
    public function block_panel($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 14
        echo "    <div style=\"position: fixed; right: 20px;\">
        <div class=\"last-upd-filter\">
            Фильтр:
            <a class=\"last-upd-filter-control\" data-type=\"0\" href=\"#\">Все</a> /
            <a class=\"last-upd-filter-control\" data-type=\"1\" href=\"#\">Давно не обновлялись</a> /
            <a class=\"last-upd-filter-control\" data-type=\"2\" href=\"#\">Обновлялись сегодня</a>";
        // line 21
        echo "        </div>

        <p class=\"errpanel\"></p><p><span id=\"search-count\"></span></p>
    </div>

    <div>
        Всего: <span id=\"total-records\">0</span> ::
        <a class=\"open-product-form\" href=\"#\">Добавить товар</a> ::
        <a id=\"table-settings\" href=\"#\">Настройки</a><br/>

        <form id=\"searchform\" style=\"display: inline;\">
            <input class=\"input2 search\" type=\"text\" name=\"search\" placeholder=\"ID, название или модель\"><input class=\"button\" type=\"submit\" value=\"Искать\">
        </form>
        <form style=\"display: inline;\" name=\"filter-form\">
        &nbsp&nbsp::&nbsp&nbsp Категория
            <select class=\"input2 select-filter\" style=\"width: 150px;\" name=\"category\"></select>
        &nbsp&nbsp::&nbsp&nbsp Бренд
            <select class=\"input2 select-filter\" style=\"width: 150px;\" name=\"brand\"></select>

            <span id=\"reset-all-filters\">&nbsp&nbsp::&nbsp&nbsp <a href=\"#\">Сбросить все фильтры</a></span>
        </form>
        <div class=\"selected_operation\">
            <span id=\"records-info\">0</span> найденых
            <span id=\"change-selected-rows\"> :: С отмеченными:
                <select id=\"change-status\" class=\"input2\" style=\"width: 100px;margin:0\">
                    <option value=\"1\">Включить</option>
                    <option value=\"0\">Выключить</option>
                </select>
                <input id=\"change-selected-rows-apply\" class=\"button\" type=\"button\" value=\"Применить\">
            </span>
        </div>
    </div>
    <div class=\"table-header-context-menu window_block\">
        <u>Показать:</u>
        <a href=\"#\" data-type=\"1\">За сегодня</a>
        <a href=\"#\" data-type=\"2\">За вчера</a>
        <a href=\"#\" data-type=\"3\">За месяц</a>
        <a href=\"#\" data-type=\"4\">За год</a>
    </div>
";
    }

    // line 62
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 63
        echo "    <div id=\"table-paging\" class=\"navi\"></div>
    <div id=\"table_block\">
        <table id=\"price_table\" class=\"display table-striped compact text-center\" style=\"width:100%\"></table>
    </div>
";
    }

    // line 69
    public function block_javascript($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 70
        echo "<script type=\"text/javascript\">
    let pp = new productPage();
</script>
";
    }

    // line 75
    public function block_style($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 76
        echo "<style>
    #table_block .info {
        float: left;
        padding-left: 10px;
    }

    #table_block .paging {
        float: right;
    }

    #table_block .tbl-block{
        padding-top: 50px;
    }
    .search {
        margin-right: 5px;
    }
</style>
";
    }

    public function getTemplateName()
    {
        return "pages/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  152 => 76,  148 => 75,  141 => 70,  137 => 69,  129 => 63,  125 => 62,  82 => 21,  75 => 14,  71 => 13,  64 => 8,  60 => 7,  55 => 4,  51 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "pages/index.twig", "/var/www/www-root/data/www/leks.sgment.ru/pricemanager_new/system/Templates/pages/index.twig");
    }
}
