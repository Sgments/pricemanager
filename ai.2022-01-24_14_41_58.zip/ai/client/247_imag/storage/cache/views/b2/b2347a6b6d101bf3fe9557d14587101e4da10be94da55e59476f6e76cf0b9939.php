<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* pages\table_settings.twig */
class __TwigTemplate_e34fbe776df2548967636588566bedf30a0fe46882904aa5f607b020eed6d91b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<div class=\"window_close\">
    <a class=\"window-close\" style=\"color:white;\" href=\"#\">Закрыть</a>
</div>

<div class=\"block\" style=\";width: 350px\">
    <h2>Редактирование таблицы</h2>
    <form id=\"table-config-form\" method=\"post\" action=\"#\" >
        <div class=\"block\" style=\"position: absolute; width: 350px; border: 0; margin-left: 370px; top: 1px;\">
            <h2>Настройки</h2>

            <div class=\"input-block\">
                <input id=\"page_length\" value=\"10\" data-item=\"page_length\" data-type=\"settings\"
                       class=\"input2 cnf-option\" type=\"text\" maxlength=\"4\">
                <label>Количество записей на страницу</label>
            </div>

            <div class=\"input-block\">
                <input id=\"showing_html\" type=\"checkbox\" value=\"1\" class=\"cnf-option\" data-item=\"showing_html\" data-type=\"settings\">
                <label for=\"showing_html\">Отображать HTML код в описании</label>
            </div>

            <div class=\"input-block\">
                <input id=\"all_images\" type=\"checkbox\" value=\"1\" class=\"cnf-option\" data-item=\"all_images\" data-type=\"settings\">
                <label for=\"all_images\">Отображать  дополнительные изображения</label>
            </div>

            <div class=\"input-block\">
                <select id=\"images_size\" class=\"input2 cnf-option\" style=\"padding:1px;margin:0;\" data-item=\"images_size\" data-type=\"settings\">
                    <option value=\"1\">50х50</option>
                    <option value=\"2\" selected>100х100</option>
                    <option value=\"3\">150х150</option>
                    <option value=\"4\">200х200</option>
                </select>
                <label for=\"images_size\">Размер изображений</label>
            </div>

            <div class=\"input-block\">
                <input id=\"category_delimiter\" value=\"10\" data-item=\"category_delimiter\" data-type=\"settings\"
                       class=\"input2 cnf-option\" type=\"text\">
                <label for=\"category_delimiter\">Разделитель для категорий</label>
            </div>

            <input id=\"submit\" class=\"button\" type=\"submit\" value=\"Сохранить\" style=\"float:right;\" maxlength=\"10\">

            <div style=\"clear:right\"></div>
        </div>

        <div class=\"columns\" style=\"overflow: auto;height: 600px;margin-top: 10px;\">
            ";
        // line 49
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["columns"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["column"]) {
            // line 50
            echo "                <div style=\"width: 312px; border-bottom: 1px solid #0ea7a0; padding-bottom: 5px\">
                    ";
            // line 51
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["column"], "name", [], "any", false, false, false, 51), "html", null, true);
            echo ": <input id=\"cnf_name_";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["column"], "name", [], "any", false, false, false, 51), "html", null, true);
            echo "\" data-item=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["column"], "name", [], "any", false, false, false, 51), "html", null, true);
            echo "\" data-type=\"name\" value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["column"], "name", [], "any", false, false, false, 51), "html", null, true);
            echo "\"
                                              class=\"input2 cnf-option\" type=\"text\" style=\"width:200px;height: 7px;
                    margin:5px;\"><br>

                    <input id=\"cnf_showing_";
            // line 55
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["column"], "name", [], "any", false, false, false, 55), "html", null, true);
            echo "\" data-item=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["column"], "name", [], "any", false, false, false, 55), "html", null, true);
            echo "\" data-type=\"visible\" type=\"checkbox\" value=\"1\" class=\"cnf-option\" checked>
                    <label for=\"cnf_showing_";
            // line 56
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["column"], "name", [], "any", false, false, false, 56), "html", null, true);
            echo "\">Отображать</label>

                    <input id=\"cnf_orderable_";
            // line 58
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["column"], "name", [], "any", false, false, false, 58), "html", null, true);
            echo "\" data-item=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["column"], "name", [], "any", false, false, false, 58), "html", null, true);
            echo "\" data-type=\"orderable\" type=\"checkbox\" value=\"1\" class=\"cnf-option\"
                           ";
            // line 59
            if (0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["column"], "name", [], "any", false, false, false, 59), "id")) {
                echo "checked";
            }
            echo ">
                    <label for=\"cnf_orderable_";
            // line 60
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["column"], "name", [], "any", false, false, false, 60), "html", null, true);
            echo "\">Сортировка</label>
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['column'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 63
        echo "        </div>

        <div class=\"err\"></div>
    </form>
</div>

<script type=\"text/javascript\">
    \$(function() {
        let sp = new settingsPage();


    });
</script>
";
    }

    public function getTemplateName()
    {
        return "pages\\table_settings.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  139 => 63,  130 => 60,  124 => 59,  118 => 58,  113 => 56,  107 => 55,  94 => 51,  91 => 50,  87 => 49,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "pages\\table_settings.twig", "F:\\server\\domains\\pricemanager.loc\\public\\system\\Templates\\pages\\table_settings.twig");
    }
}
