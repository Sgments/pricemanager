<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* page.twig */
class __TwigTemplate_7c715c99f3323c603a8afb1616254f872f99f0280677deef39da8950552c21e1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'title' => [$this, 'block_title'],
            'style' => [$this, 'block_style'],
            'panel' => [$this, 'block_panel'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
            'javascript' => [$this, 'block_javascript'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"ru\">

<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
\t<base href=\"";
        // line 7
        echo twig_escape_filter($this->env, ($context["APP_HOST"] ?? null), "html", null, true);
        echo "/\" />

    ";
        // line 9
        $this->displayBlock('head', $context, $blocks);
        // line 12
        echo "
    <link rel=\"stylesheet\" href=\"content/vendor/fontawesome/css/all.min.css\">
    <link rel=\"stylesheet\" href=\"content/vendor/toastr/toastr.min.css\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"content/vendor/DataTables/datatables.min.css\"/>
    <link rel=\"stylesheet\" type=\"text/css\" href=\"content/vendor/select2/css/select2.min.css\"/>
    <link rel=\"stylesheet\" href=\"content/style/page.css\">

    <script type=\"text/javascript\" src=\"content/vendor/jQuery-3.6.0/jquery-3.6.0.min.js\"></script>
    <script type=\"text/javascript\" src=\"content/vendor/toastr/toastr.min.js\"></script>
    <script type=\"text/javascript\" src=\"content/vendor/DataTables/datatables.min.js\"></script>
    <script type=\"text/javascript\" src=\"content/vendor/select2/js/select2.full.min.js\"></script>
    <script type=\"text/javascript\" src=\"content/vendor/select2/js/i18n/ru.js\"></script>
    <script type=\"text/javascript\" src=\"content/js/system.js\"></script>

    ";
        // line 26
        $this->displayBlock('style', $context, $blocks);
        // line 27
        echo "</head>

<body>

    <div id=\"loading\"><div class=\"pe-loader\"></div></div>
    <div id=\"window\"></div>

    <div class=\"panel\">
        <div class=\"panel_top\">
            <a href=\"#\">Каталог</a>
            <a href=\"#\">Магазины</a>
            <a href=\"#\">Категории</a>
            <a href=\"#\">Бренды</a>
            <a href=\"#\">Пользователи</a>
            <a href=\"#\">Отзывы</a>
            <a href=\"#\">SEO</a>
            <a href=\"#\">Настройки</a>
            <a style=\"border:0;\" href=\"#\">Выход</a>
        </div>

        ";
        // line 47
        $this->displayBlock('panel', $context, $blocks);
        // line 48
        echo "    </div>

    <div class=\"content\">
        ";
        // line 51
        $this->displayBlock('content', $context, $blocks);
        // line 52
        echo "    </div>

    ";
        // line 54
        $this->displayBlock('footer', $context, $blocks);
        // line 55
        echo "
    <script type=\"text/javascript\">
        var sys = new system();
        sys.config.storeSettings({host: '";
        // line 58
        echo twig_escape_filter($this->env, ($context["APP_HOST"] ?? null), "html", null, true);
        echo "'})

        toastr.options = {
            \"closeButton\": true,
            \"newestOnTop\": true,
            \"progressBar\": true,
            \"positionClass\": \"toast-top-right\",
            \"preventDuplicates\": true,
            \"timeOut\": \"2000\",
        }
    </script>

    ";
        // line 70
        $this->displayBlock('javascript', $context, $blocks);
        // line 71
        echo "</body>
</html>
";
    }

    // line 9
    public function block_head($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 10
        echo "        <title>";
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
    }

    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 26
    public function block_style($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 47
    public function block_panel($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 51
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 54
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 70
    public function block_javascript($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    public function getTemplateName()
    {
        return "page.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  182 => 70,  176 => 54,  170 => 51,  164 => 47,  158 => 26,  146 => 10,  142 => 9,  136 => 71,  134 => 70,  119 => 58,  114 => 55,  112 => 54,  108 => 52,  106 => 51,  101 => 48,  99 => 47,  77 => 27,  75 => 26,  59 => 12,  57 => 9,  52 => 7,  44 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "page.twig", "/var/www/www-root/data/www/leks.sgment.ru/pricemanager_new/system/Templates/page.twig");
    }
}
