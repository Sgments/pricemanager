<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* pages\product_form.twig */
class __TwigTemplate_2c3e7d30bea576c6a06277ba3234bd3c7ac8e14d4e15e0f1a5b43969032e68b3 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<div class=\"window_close\">
    <a class=\"window-close\" style=\"color:white\" href=\"#\">Закрыть</a>
</div>

<div class=\"block\" style=\"width: 500px;\">
    <h2>
        ";
        // line 7
        if (1 === twig_compare(($context["productId"] ?? null), 0)) {
            echo " Редактировать ";
        } else {
            echo " Добавить ";
        }
        echo " товар ";
        if (1 === twig_compare(($context["productId"] ?? null), 0)) {
            // line 8
            echo "            <span title=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["dataFields"] ?? null), "name", [], "any", false, false, false, 8), "value", [], "any", false, false, false, 8), "html", null, true);
            echo "\">(";
            echo twig_escape_filter($this->env, ($context["productId"] ?? null), "html", null, true);
            echo ")</span> ";
        }
        // line 9
        echo "    </h2>

    <form id=\"product-form\" method=\"post\" action=\"#\">
        <div class=\"block\" style=\"position: absolute; width: 220px; border: 0; margin-left: 520px; top: 2px;\">
            <h2>Изображения</h2>
            ";
        // line 14
        if (1 === twig_compare(twig_length_filter($this->env, ($context["images"] ?? null)), 0)) {
            // line 15
            echo "            <img class=\"cover\" src=\"";
            echo twig_escape_filter($this->env, (($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 = ($context["images"] ?? null)) && is_array($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4) || $__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 instanceof ArrayAccess ? ($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4[0] ?? null) : null), "html", null, true);
            echo "\">
            ";
        }
        // line 17
        echo "
            <input class=\"input\" style=\"width:95%;\" type=\"text\" name=\"images[]\" placeholder=\"URL\" value=\"";
        // line 18
        echo twig_escape_filter($this->env, (($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 = ($context["images"] ?? null)) && is_array($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144) || $__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 instanceof ArrayAccess ? ($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144[0] ?? null) : null), "html", null, true);
        echo "\">
            <p><b>Дополнительные изображения:</b></p>
            <a id=\"add-image\" href=\"#\" class=\"button\" >Добавить изображение</a>
            <div id=\"additional-images\" style=\"overflow: auto;height: 406px;margin-top: 10px\">
                <div class=\"new-image\" style=\"display: none\">
                    <img class=\"moreimg\">
                    <input class=\"input\" style=\"width:79%; float: left;\" type=\"text\" name=\"images[]\" placeholder=\"URL\" disabled>
                    <a style=\"float: right; padding: 10px; color: red;\" class=\"remove_field\" href=\"#\"><b>x</b></a>
                </div>

                ";
        // line 28
        if (1 === twig_compare(twig_length_filter($this->env, ($context["images"] ?? null)), 0)) {
            // line 29
            echo "                    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_slice($this->env, ($context["images"] ?? null), 1, null));
            foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
                // line 30
                echo "                        <div>
                            <img class=\"moreimg\" src=\"";
                // line 31
                echo twig_escape_filter($this->env, $context["image"], "html", null, true);
                echo "\">
                            <img class=\"moreimg\">
                            <input class=\"input\" style=\"width:79%; float: left;\" type=\"text\" name=\"images[]\" placeholder=\"URL\"
                                   value=\"";
                // line 34
                echo twig_escape_filter($this->env, $context["image"], "html", null, true);
                echo "\">
                            <a style=\"float: right; padding: 10px; color: red;\" class=\"remove_field\" href=\"#\"><b>x</b></a>
                        </div>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 38
            echo "                ";
        }
        // line 39
        echo "            </div>
        </div>
        <div class=\"columns\" style=\"overflow: auto;height: 600px;margin-top: 10px;\">
        ";
        // line 42
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["dataFields"] ?? null));
        foreach ($context['_seq'] as $context["field_name"] => $context["field"]) {
            // line 43
            echo "            ";
            if (0 !== twig_compare($context["field_name"], "images")) {
                // line 44
                echo "            <div style=\"margin-bottom: 5px\">
                <b>";
                // line 45
                echo twig_escape_filter($this->env, $context["field_name"], "html", null, true);
                echo "</b>
                <input name=\"";
                // line 46
                echo twig_escape_filter($this->env, $context["field_name"], "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["field"], "value", [], "any", false, false, false, 46), "html", null, true);
                echo "\" class=\"input item-field\" type=\"text\">
            </div>
            ";
            }
            // line 49
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['field_name'], $context['field'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "        </div>
        <input name=\"id\" type=\"hidden\" value=\"";
        // line 51
        echo twig_escape_filter($this->env, ($context["productId"] ?? null), "html", null, true);
        echo "\">
        <input id=\"submit\" class=\"button\" type=\"submit\" value=\"Сохранить\">
    </form>
</div>

<script type=\"text/javascript\">
    \$(function() {
        new productForm();
    });
</script>
";
    }

    public function getTemplateName()
    {
        return "pages\\product_form.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  156 => 51,  153 => 50,  147 => 49,  139 => 46,  135 => 45,  132 => 44,  129 => 43,  125 => 42,  120 => 39,  117 => 38,  107 => 34,  101 => 31,  98 => 30,  93 => 29,  91 => 28,  78 => 18,  75 => 17,  69 => 15,  67 => 14,  60 => 9,  53 => 8,  45 => 7,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "pages\\product_form.twig", "F:\\server\\domains\\pricemanager.loc\\public\\system\\Templates\\pages\\product_form.twig");
    }
}
