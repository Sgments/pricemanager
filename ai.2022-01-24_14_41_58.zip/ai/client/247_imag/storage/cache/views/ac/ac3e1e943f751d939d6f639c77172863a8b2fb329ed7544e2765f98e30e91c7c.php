<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* page.twig */
class __TwigTemplate_b207d0a773c41e85697351a335f60a3fb8fb44263ac745c58d2db5930a76493c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'title' => [$this, 'block_title'],
            'style' => [$this, 'block_style'],
            'panel' => [$this, 'block_panel'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
            'javascript' => [$this, 'block_javascript'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"ru\">

<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">

    ";
        // line 8
        $this->displayBlock('head', $context, $blocks);
        // line 11
        echo "
    <link rel=\"stylesheet\" href=\"/content/vendor/fontawesome/css/all.min.css\">
    <link rel=\"stylesheet\" href=\"/content/vendor/toastr/toastr.min.css\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"/content/vendor/DataTables/datatables.min.css\"/>
    <link rel=\"stylesheet\" type=\"text/css\" href=\"/content/vendor/select2/css/select2.min.css\"/>
    <link rel=\"stylesheet\" href=\"/content/style/page.css\">

    <script type=\"text/javascript\" src=\"/content/vendor/jQuery-3.6.0/jquery-3.6.0.min.js\"></script>
    <script type=\"text/javascript\" src=\"/content/vendor/toastr/toastr.min.js\"></script>
    <script type=\"text/javascript\" src=\"/content/vendor/DataTables/datatables.min.js\"></script>
    <script type=\"text/javascript\" src=\"/content/vendor/select2/js/select2.full.min.js\"></script>
    <script type=\"text/javascript\" src=\"/content/vendor/select2/js/i18n/ru.js\"></script>
    <script type=\"text/javascript\" src=\"/content/js/system.js\"></script>

    ";
        // line 25
        $this->displayBlock('style', $context, $blocks);
        // line 26
        echo "</head>

<body>

    <div id=\"loading\"><div class=\"pe-loader\"></div></div>
    <div id=\"window\"></div>

    <div class=\"panel\">
        <div class=\"panel_top\">
            <a href=\"#\">Каталог</a>
            <a href=\"#\">Магазины</a>
            <a href=\"#\">Категории</a>
            <a href=\"#\">Бренды</a>
            <a href=\"#\">Пользователи</a>
            <a href=\"#\">Отзывы</a>
            <a href=\"#\">SEO</a>
            <a href=\"#\">Настройки</a>
            <a style=\"border:0;\" href=\"#\">Выход</a>
        </div>

        ";
        // line 46
        $this->displayBlock('panel', $context, $blocks);
        // line 47
        echo "    </div>

    <div class=\"content\">
        ";
        // line 50
        $this->displayBlock('content', $context, $blocks);
        // line 51
        echo "    </div>

    ";
        // line 53
        $this->displayBlock('footer', $context, $blocks);
        // line 54
        echo "
    <script type=\"text/javascript\">
        var sys = new system();
        sys.config.storeSettings({host: '";
        // line 57
        echo twig_escape_filter($this->env, ($context["APP_HOST"] ?? null), "html", null, true);
        echo "'})

        toastr.options = {
            \"closeButton\": true,
            \"newestOnTop\": true,
            \"progressBar\": true,
            \"positionClass\": \"toast-top-right\",
            \"preventDuplicates\": true,
            \"timeOut\": \"2000\",
        }
    </script>

    ";
        // line 69
        $this->displayBlock('javascript', $context, $blocks);
        // line 70
        echo "</body>
</html>
";
    }

    // line 8
    public function block_head($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 9
        echo "        <title>";
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
    }

    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 25
    public function block_style($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 46
    public function block_panel($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 50
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 53
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 69
    public function block_javascript($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    public function getTemplateName()
    {
        return "page.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  178 => 69,  172 => 53,  166 => 50,  160 => 46,  154 => 25,  142 => 9,  138 => 8,  132 => 70,  130 => 69,  115 => 57,  110 => 54,  108 => 53,  104 => 51,  102 => 50,  97 => 47,  95 => 46,  73 => 26,  71 => 25,  55 => 11,  53 => 8,  44 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "page.twig", "F:\\server\\domains\\pricemanager.loc\\public\\system\\Templates\\page.twig");
    }
}
