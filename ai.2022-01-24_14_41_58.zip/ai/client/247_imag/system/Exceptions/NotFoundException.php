<?php

namespace System\Exceptions;

class NotFoundException extends \Exception
{
}
